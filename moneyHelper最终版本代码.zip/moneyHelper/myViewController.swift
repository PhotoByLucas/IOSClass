//
//  myViewController.swift
//  moneyHelper
//
//  Created by Apple on 2019/11/5.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class myViewController: UIViewController{
//    let ctrlName = ["理财助手", "投资", "存钱宝", "一起来买房", "贷贷我"];
//    var tableView:UITableView?;
//
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return ctrlName.count;
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let identify = "SwiftCell";
//        /// 同一形式的单元格重复使用，在声明时已注册
//        let cell = tableView.dequeueReusableCell(withIdentifier: identify, for: indexPath);
//        cell.accessoryType = UITableViewCell.AccessoryType.disclosureIndicator;
//        cell.textLabel?.text = ctrlName[indexPath.row];
//
//        return cell;
//    }
//
//    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
//
//        tableView.deselectRow(at: indexPath as IndexPath, animated: true);
//        let itemString = ctrlName[indexPath.row];
//
//        /// 创建提示框
//        let alertView = UIAlertController(title: "提示", message: "你选中了\(itemString)", preferredStyle: .alert);
//        /// 向提示框中增加按钮
//        let alertAction = UIAlertAction(title: "确定", style: UIAlertAction.Style.default, handler: {(action)->Void in});
//        alertView.addAction(alertAction);
//
//        present(alertView, animated:true, completion:nil);
//    }
    
    var List: list?
    func initList(){
        //loadListFile()
        List=list(name: "hua", account: "123", listAvatar: nil)
    }
    func saveListFile(){
        let success = NSKeyedArchiver.archiveRootObject(List, toFile: list.ArchiveURL.path)
        if !success{
            print("Failed...")
        }
    }
    @IBOutlet weak var selfPicture: UIImageView!
    @IBOutlet weak var nickname: UILabel!
    @IBOutlet weak var account: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        //initList()
//        tableView=UITableView(frame: CGRect(x:0, y:200, width: 420,height: 3000),style: .plain)
//        //tableView = UITableView(frame: view.frame, style: .plain);
//        tableView!.dataSource = self;
//        tableView!.delegate = self;
//
//        tableView?.register(UITableViewCell.self, forCellReuseIdentifier: "SwiftCell");
//        view.addSubview(tableView!);
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let defaultList = loadListFile(){
            List = defaultList
            self.nickname.text=List?.name
            self.selfPicture.image=List?.listAvatar
            self.account.text="账号：123"
        }
    }
    
    
   
    
    
    
    
    func loadListFile()->list?{
        //return (NSKeyedUnarchiver.unarchivedObject(withFile: list.ArchiveURL.path) as? [list])
        return (NSKeyedUnarchiver.unarchiveObject(withFile: list.ArchiveURL.path) as? list)
    }
    
    
    @IBAction func cancelToList(segue: UIStoryboardSegue){
        
    }
    @IBAction func saveToList(segue: UIStoryboardSegue){
        if let addListVC=segue.source as? changeViewController{
            if let addList=addListVC.listForEdit{
                List=addList
                
                saveListFile()
                
            }
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    //多目的地如何解决？
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "picture"{
              var monryVC = segue.destination as! changeViewController
             monryVC.listForEdit=List
        }
        if segue.identifier == "name"{
            var monryVC = segue.destination as! changeViewController
            monryVC.listForEdit=List
        }
        if segue.identifier == "p1"{
            var monryVC = segue.destination as! extraViewController
        }
        if segue.identifier == "p2"{
            var monryVC = segue.destination as! extraViewController
        }
        if segue.identifier == "p3"{
            var monryVC = segue.destination as! extraViewController
        }
        if segue.identifier == "p4"{
            var monryVC = segue.destination as! extraViewController
        }
    }
}
