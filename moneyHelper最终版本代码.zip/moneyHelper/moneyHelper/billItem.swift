//
//  billItem.swift
//  moneyHelper
//
//  Created by Apple on 2019/11/26.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
import UIKit

class billItem: NSObject, NSCoding
{
    var amount:Double?
    var type: String?
    var time: String?
    
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(amount, forKey: "amountKey")
        aCoder.encode(type, forKey: "typeKey")
        aCoder.encode(time, forKey: "timeKey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        amount=aDecoder.decodeObject(forKey: "amountKey") as? Double
        type=aDecoder.decodeObject(forKey: "typeKey") as? String
        time=aDecoder.decodeObject(forKey: "timeKey") as? String
    }
    
    static let DocumentsDirectory=FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL=DocumentsDirectory.appendingPathComponent("billList")
    
    init(amount: Double?, type: String?, time: String?)
    {
        self.amount=amount
        self.type=type
        self.time=time
    }
}
