//
//  ViewController.swift
//  moneyHelper
//
//  Created by Apple on 2019/10/22.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var account: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBAction func login(_ sender: Any) {
            if ( ( account.text == "123") && ( password.text == "asd123") ){
                let view = self.storyboard?.instantiateViewController(withIdentifier: "UITabBarController")as!UITabBarController
                self.present(view, animated: true, completion: nil)
            }
            
            if (account.text != "123"){
                hintLabel.isHidden = false
                hintLabel.text = "账号错误"
            }
            else if ((account.text == "123") && ( password.text != "asd123")){
                hintLabel.isHidden = false
                hintLabel.text = "密码错误，请重新输入密码"
            }
    
        
        }
    
    
    @IBAction func signup(_ sender: Any) {
        let view=self.storyboard?.instantiateViewController(withIdentifier: "signUpViewController")as!signUpViewController
        self.navigationController?.pushViewController(view, animated: true)
    }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        account.clearButtonMode = .whileEditing
        password.clearButtonMode = .whileEditing
        password.isSecureTextEntry=true
        // Do any additional setup after loading the view.
    }


}

