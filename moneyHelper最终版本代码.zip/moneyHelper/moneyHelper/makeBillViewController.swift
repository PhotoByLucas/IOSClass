//
//  makeBillViewController.swift
//  moneyHelper
//
//  Created by Apple on 2019/11/26.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class makeBillViewController: UIViewController ,UIPickerViewDelegate,
UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
       return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 9
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return typeArr[row]//String(row) + "-" + String(component)
        //return String(component)
    }
    
   
    

    @IBOutlet weak var typePicker: UIPickerView!
    @IBOutlet weak var itemTime: UIDatePicker!
    @IBOutlet weak var itemText: UITextField!
    
    var amount:NSString?
    var time: String?
    var type: String? = "餐饮"
    let typeArr=["娱乐","餐饮","烟酒","零食","购物","交通","通讯","工资","医疗"]
    /*
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 9
    }
    
    
    }*/
    

    override func viewDidLoad() {
        super.viewDidLoad()
      //  let typePicker=UIPickerView()
        typePicker.delegate=self
        typePicker.dataSource=self
        typePicker.selectRow(1, inComponent: 0, animated: true)
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier=="saveToBill"
        {
            print("save")
            
            amount=itemText.text! as NSString
            
            let date=itemTime.date
            let dateFormatter=DateFormatter()
            dateFormatter.dateFormat="yyyy年MM月dd日"
            time=dateFormatter.string(from: date)
        }
        if segue.identifier=="cancelToHere"
        {
            print("cancel")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        type=typeArr[row]
    }
}
