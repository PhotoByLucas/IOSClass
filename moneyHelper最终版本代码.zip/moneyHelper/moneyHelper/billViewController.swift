//
//  billViewController.swift
//  moneyHelper
//
//  Created by Apple on 2019/11/26.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class billViewController: UIViewController {

    
    @IBOutlet weak var totalAmount: UILabel!
    var sum: Double?
    
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var label4: UILabel!
    @IBOutlet weak var label5: UILabel!
    @IBOutlet weak var label6: UILabel!
    @IBOutlet weak var label7: UILabel!
    @IBOutlet weak var label8: UILabel!
    @IBOutlet weak var label9: UILabel!
    var item1 = 0.0
    var item2 = 0.0
    var item3 = 0.0
    var item4 = 0.0
    var item5 = 0.0
    var item6 = 0.0
    var item7 = 0.0
    var item8 = 0.0
    var item9 = 0.0
    
   /* var billList: [billItem] = [billItem] ()
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        print("viewDidLoad")
        if let defaultBillList=loadBillFile()
        {
            billList=defaultBillList
            sum=0;
            for i in 0...billList.count-1
            {
                if(billList[i].type != "工资")
                {
                    sum=sum!+billList[i].amount!
                }
                else
                {
                    sum=sum!-billList[i].amount!
                }
            }
            let sum1 = sum!
            self.totalAmount.text="\(sum1)"
            
        }
        else
        {
            totalAmount.text="0";
            sum=0
        }
        statistics()
    }
    
    //回退至此
    @IBAction func cancelTohere(segue: UIStoryboardSegue) {
        print("cancel")
    }
    
    //保存后会退至此
    @IBAction func saveToBill(segue: UIStoryboardSegue) {
        if let addBillVC=segue.source as? makeBillViewController
        {
            
            if let addItem=addBillVC.amount
            {
                print(addBillVC.time)
                billList.append(billItem(amount: addItem.doubleValue, type: addBillVC.type, time: addBillVC.time))//billItem (amount :addItem.doubleValue, type :addBillVC.type, time :addBillVC.time))
                if(addBillVC.type != "工资")
                {
                    sum=addItem.doubleValue+sum!
                }
                else
                {
                    sum=sum!-addItem.doubleValue
                }
                
                let sum1 = sum!
                self.totalAmount.text="\(sum1)"  //更新支出信息
                statistics()  //更新统计信息
                
                saveBillFile()
                
            }
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    func saveBillFile()
    {
        let success = NSKeyedArchiver.archiveRootObject(billList, toFile: billItem.ArchiveURL.path)
        if !success{
            print("Failed...")
        }
    }
    
    func loadBillFile() ->[billItem]?
    {
        print("load")
        return (NSKeyedUnarchiver.unarchiveObject(withFile: billItem.ArchiveURL.path) as? [billItem])
    }
    
    func statistics()
    {
        for i in 0...billList.count-1
        {
            if(billList[i].type=="娱乐")
            {
                item1+=billList[i].amount!
            }
            if(billList[i].type=="餐饮")
            {
                item2+=billList[i].amount!
            }
            if(billList[i].type=="烟酒")
            {
                item3+=billList[i].amount!
            }
            if(billList[i].type=="零食")
            {
                item4+=billList[i].amount!
            }
            if(billList[i].type=="购物")
            {
                item5+=billList[i].amount!
            }
            if(billList[i].type=="交通")
            {
                item6+=billList[i].amount!
            }
            if(billList[i].type=="通讯")
            {
                item7+=billList[i].amount!
            }
            if(billList[i].type=="工资")
            {
                item8+=billList[i].amount!
            }
            if(billList[i].type=="医疗")
            {
                item9+=billList[i].amount!
            }
        }
        self.label1.text="\(item1)"
        self.label2.text="\(item2)"
        self.label3.text="\(item3)"
        self.label4.text="\(item4)"
        self.label5.text="\(item5)"
        self.label6.text="\(item6)"
        self.label7.text="\(item7)"
        self.label8.text="\(item8)"
        self.label9.text="\(item9)"
    }*/
    
    var billList: [billItem] = [billItem] ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        print("viewDidLoad")
        if let defaultBillList=loadBillFile()
        {
            billList=defaultBillList
            sum=0;
            for i in 0...billList.count-1
            {
                if(billList[i].type != "工资")
                {
                    sum=sum!+billList[i].amount!
                }
                else
                {
                    sum=sum!-billList[i].amount!
                }
            }
            let sum1 = sum!
            self.totalAmount.text="\(sum1)"
            
        }
        else
        {
            totalAmount.text="0";
            sum=0
        }
        statistics()
    }
    
    //回退至此
    @IBAction func cancelTohere(segue: UIStoryboardSegue) {
        print("cancel")
    }
    
    //保存后会退至此
    @IBAction func saveToBill(segue: UIStoryboardSegue) {
        if let addBillVC=segue.source as? makeBillViewController
        {
            
            if let addItem=addBillVC.amount
            {
                print(addBillVC.time)
                billList.append(billItem(amount: addItem.doubleValue, type: addBillVC.type, time: addBillVC.time))//billItem (amount :addItem.doubleValue, type :addBillVC.type, time :addBillVC.time))
                if(addBillVC.type != "工资")
                {
                    sum=addItem.doubleValue+sum!
                }
                else
                {
                    sum=sum!-addItem.doubleValue
                }
                
                let sum1 = sum!
                self.totalAmount.text="\(sum1)"  //更新支出信息
                newStatistic()  //更新统计信息
                
                saveBillFile()
                
            }
        }
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    func saveBillFile()
    {
        let success = NSKeyedArchiver.archiveRootObject(billList, toFile: billItem.ArchiveURL.path)
        if !success{
            print("Failed...")
        }
    }
    
    func loadBillFile() ->[billItem]?
    {
        print("load")
        return (NSKeyedUnarchiver.unarchiveObject(withFile: billItem.ArchiveURL.path) as? [billItem])
    }
    
    func statistics()
    {
        for i in 0...billList.count-1
        {
            if(billList[i].type=="娱乐")
            {
                item1+=billList[i].amount!
            }
            if(billList[i].type=="餐饮")
            {
                item2+=billList[i].amount!
            }
            if(billList[i].type=="烟酒")
            {
                item3+=billList[i].amount!
            }
            if(billList[i].type=="零食")
            {
                item4+=billList[i].amount!
            }
            if(billList[i].type=="购物")
            {
                item5+=billList[i].amount!
            }
            if(billList[i].type=="交通")
            {
                item6+=billList[i].amount!
            }
            if(billList[i].type=="通讯")
            {
                item7+=billList[i].amount!
            }
            if(billList[i].type=="工资")
            {
                item8+=billList[i].amount!
            }
            if(billList[i].type=="医疗")
            {
                item9+=billList[i].amount!
            }
        }
        self.label1.text="\(item1)"
        self.label2.text="\(item2)"
        self.label3.text="\(item3)"
        self.label4.text="\(item4)"
        self.label5.text="\(item5)"
        self.label6.text="\(item6)"
        self.label7.text="\(item7)"
        self.label8.text="\(item8)"
        self.label9.text="\(item9)"
    }
    
    func newStatistic()
    {
        if(billList[billList.count-1].type=="娱乐")
        {
            item1+=billList[billList.count-1].amount!
            self.label1.text="\(item1)"
        }
        if(billList[billList.count-1].type=="餐饮")
        {
            item2+=billList[billList.count-1].amount!
            self.label2.text="\(item2)"
        }
        if(billList[billList.count-1].type=="烟酒")
        {
            item3+=billList[billList.count-1].amount!
            self.label3.text="\(item3)"
        }
        if(billList[billList.count-1].type=="零食")
        {
            item4+=billList[billList.count-1].amount!
            self.label4.text="\(item4)"
        }
        if(billList[billList.count-1].type=="购物")
        {
            item5+=billList[billList.count-1].amount!
            self.label5.text="\(item5)"
        }
        if(billList[billList.count-1].type=="交通")
        {
            item6+=billList[billList.count-1].amount!
            self.label6.text="\(item6)"
        }
        if(billList[billList.count-1].type=="通讯")
        {
            item7+=billList[billList.count-1].amount!
            self.label7.text="\(item7)"
        }
        if(billList[billList.count-1].type=="工资")
        {
            item8+=billList[billList.count-1].amount!
            self.label8.text="\(item8)"
        }
        if(billList[billList.count-1].type=="医疗")
        {
            item9+=billList[billList.count-1].amount!
            self.label9.text="\(item9)"
        }
    }

}
