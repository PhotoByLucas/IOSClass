//
//  signUpViewController.swift
//  moneyHelper
//
//  Created by Apple on 2019/11/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class signUpViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func signup(_ sender: Any) {
        let alert = UIAlertController(title:nil, message:"注册成功", preferredStyle: .alert)
        let loginAction=UIAlertAction(title: "去登录", style: .default, handler:{act in
            let view = self.storyboard?.instantiateViewController(withIdentifier:"ViewController")as!ViewController
       self.present(view, animated: true, completion: nil)
        })
        alert.addAction(loginAction)
        self.present(alert,animated: true,completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
