//
//  list.swift
//  moneyHelper
//
//  Created by Apple on 2019/11/12.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
import UIKit
class list :NSObject,NSCoding {
    func encode(with aCoder: NSCoder) {
        aCoder.encode(name, forKey: "nameKey")
        aCoder.encode(account, forKey: "accoutnKey")
        aCoder.encode(listAvatar, forKey: "avatarKey")
    }
    
    required init?(coder aDecoder: NSCoder) {
        name = aDecoder.decodeObject(forKey: "nameKey") as? String
        account = aDecoder.decodeObject(forKey: "accountKey") as? String
        listAvatar = aDecoder.decodeObject(forKey: "avatarKey") as? UIImage
    }
    
    var name: String?
    var account: String?
    var listAvatar: UIImage?
    static let DocumentsDirectory = FileManager().urls(for: .documentDirectory, in: .userDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.appendingPathComponent("List")
    init(name: String?,account: String?,listAvatar: UIImage?) {
        self.name=name
        self.account=account
        self.listAvatar = listAvatar
    }
}
